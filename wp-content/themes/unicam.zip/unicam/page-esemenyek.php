<?php
/*
Template Name: Események
*/
?>

<?php get_header(); ?>

<section class="events-list">
    <div class="container">
      <div class="row list-row">
        <h1 class="pagetitle visible-sm visible-xs">
          Események
        </h1>
        <?php $args = array(
            'post_type' => 'esemenyek',
            'posts_per_page' => -1
        );
        $the_query = new WP_Query($args);
        ?>
        <?php while ($the_query->have_posts()) : $the_query->the_post(); ?>
        <article class="single-event">
          <div class="container">
            <div class="row">
              <div class="col-lg-4 col-md-4 left">
                <header>
                  <h2 class="title">
                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                  </h2>
                </header>
                  <div class="date">
                    <?php
                    $date = get_field('esemeny_datuma', false, false);
                    $date = new DateTime($date);
                    ?>
                    <?php echo $date->format('Y.m.d.'); ?>
                  </div>
                  <!-- div class="address">
                    <?php
                    if( get_post_type() == 'esemenyek' ) {
                        the_field('esemeny_helyszine_szoveggel');
                    }
                    ?>
                  </div -->
              </div>
              <div class="col-lg-8 col-md-8 right">
                <?php echo get_excerpt(); ?>
                <div class="more-link">
                  <a href="<?php the_permalink(); ?>">
                    Tovább az eseményhez >
                  </a>
                </div>
              </div>
            </div>
          </div>
        </article>
      <?php endwhile; ?>
      </div>
    </div>
</section>

<?php get_footer(); ?>
