Bootstrap-Starter
=================

Starter project for Bootstrap 3 projects with Font Awesome.

Created for easy prototyping projects with Bootstrap 3 and Font Awesome. Build by company standard, not recommended for anyone.

<i>/fonts</i> - Font Awesome fonts<br />
<i>/js</i> - basic 1.11 jQuery and bootstrap.js Other jQuery files should be placed here<br />
<i>/less</i> - for custom .less files, and all of the Bootstrap styles placed here<br />
<i>/sitebuild</i> - main html directory, all created pages should be placed here. Also the admin is in this directory<br />
<i>/stylesheet</i> - bacis Font Awesome css here, and styles.css what is generated from all the less files 
