<?php
/*
Template Name: Szerviz
*/
?>

<?php get_header(); ?>

<section class="service page">
  <div class="container">
    <h1 class="pagetitle visible-sm visible-xs">
      Szerviz
    </h1>
    <div class="page-lead">
      <p>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam pulvinar turpis turpis, et rhoncus turpis fermentum at. Duis eget sagittis felis. Donec eget pharetra odio, eget congue nulla. Curabitur suscipit lorem dolor, a tristique elit congue in. Donec euismod tellus vitae turpis eleifend placerat. Nunc commodo enim nec justo laoreet luctus. Integer dapibus neque vitae ipsum imperdiet euismod. Vestibulum sit amet justo vel ante tempus iaculis.
      </p>
    </div>
    <div class="row service-divisions">
      <div class="col-lg-6 col-md-6 one-division">
        <h2 class="subtitle">
          Analitikai üzletág
        </h2>
        <div class="contact">
          <div class="tel">
            <a href="tel: 1-2215536">Telefon: 1-2215536</a>
          </div>
          <div class="email">
            <a href="mailto: unicam@unicam.hu">unicam@unicam.hu</a>
          </div>
        </div>
      </div>
      <div class="col-lg-6 col-md-6 one-division">
        <h2 class="subtitle">
          Mikroszkópia
        </h2>
        <div class="contact">
          <div class="tel">
            <a href="tel: 1-2215536">Telefon: 1-2215536</a>
          </div>
          <div class="email">
            <a href="mailto: unicam@unicam.hu">unicam@unicam.hu</a>
          </div>
        </div>
      </div>
    </div>
    <div class="service-errorsubmit">
      <div class="top">
        <button class="button-main errorsubmit-trigger">
            Hibajelentés
            <span class="icon arrow-down" title="Olvasom"></span>
        </button>
      </div>
      <div class="service-form-wrapper">
        <?php echo do_shortcode('[contact-form-7 id="1127" title="Hibajelentő"]'); ?>
      </div>
    </div>
  </div>
</section>


<?php get_footer(); ?>
